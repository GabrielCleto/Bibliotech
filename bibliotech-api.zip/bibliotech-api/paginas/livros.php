<?php
// livros.php — lista simples do acervo (título, autor, categoria,
// quantas cópias tem disponível). Qualquer pessoa logada pode ver.

session_start();
require __DIR__ . "/../config/Conexao.php";

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$conexao = Conexao::getConexao();
$tipo = $_SESSION["tipo_usuario"];
$ehBibliotecario = ($tipo === "bibliotecario" || $tipo === "admin");
$podeSolicitar = ($tipo === "aluno" || $tipo === "professor");

$sql = "SELECT L.id_livro, L.titulo, A.nome_autor, C.nome_cat, L.quantidade_disponivel, L.quantidade_total
        FROM livros L
        INNER JOIN autores A ON A.id_autor = L.id_autor
        INNER JOIN categorias C ON C.id_cat = L.id_cat
        ORDER BY L.titulo";
$livros = $conexao->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Acervo - Biblioteca Virtual</title>
</head>
<body>
    <h2>Acervo de livros</h2>

    <?php if ($ehBibliotecario): ?>
        <p><a href="cadastro_livro.php">Cadastrar novo livro</a></p>
    <?php endif; ?>

    <table border="1" cellpadding="6">
        <tr>
            <th>Título</th>
            <th>Autor</th>
            <th>Categoria</th>
            <th>Disponíveis</th>
            <?php if ($ehBibliotecario || $podeSolicitar): ?>
                <th></th>
            <?php endif; ?>
        </tr>
        <?php foreach ($livros as $livro): ?>
            <tr>
                <td><?= htmlspecialchars($livro["titulo"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($livro["nome_autor"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($livro["nome_cat"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= $livro["quantidade_disponivel"] ?> de <?= $livro["quantidade_total"] ?></td>
                <?php if ($ehBibliotecario): ?>
                    <td><a href="editar_livro.php?id=<?= $livro["id_livro"] ?>">Editar</a></td>
                <?php elseif ($podeSolicitar): ?>
                    <td>
                        <?php if ($livro["quantidade_disponivel"] > 0): ?>
                            <a href="solicitar_emprestimo.php?id_livro=<?= $livro["id_livro"] ?>">Solicitar</a>
                        <?php else: ?>
                            Indisponível
                        <?php endif; ?>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
    </table>

    <p><a href="principal.php">Voltar</a></p>
</body>
</html>
