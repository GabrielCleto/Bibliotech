<?php
// login.php — tela de login de verdade.
// Usa a classe Usuario (já testada) pra conferir e-mail e senha.

session_start();
require __DIR__ . "/../config/Conexao.php";
require __DIR__ . "/../models/Usuario.php";

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";

    $resultado = Usuario::autenticar($email, $senha);

    if ($resultado["sucesso"]) {
        // Troca o "número" da sessão por um novo, por segurança
        // (evita que alguém reaproveite uma sessão antiga)
        session_regenerate_id(true);

        $_SESSION["id_usuario"] = $resultado["usuario"]->pegarId();
        $_SESSION["nome"] = $resultado["usuario"]->pegarNome();
        $_SESSION["tipo_usuario"] = $resultado["usuario"]->pegarTipoUsuario();

        // Login deu certo: manda pra página principal
        header("Location: principal.php");
        exit;
    }

    $mensagem = $resultado["mensagem"];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login — Bibliotech</title>
</head>
<body>
    <form method="post" action="login.php">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" required>

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required>

        <button type="submit">Entrar</button>
    </form>

    <p id="resultado"><?= htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8") ?></p>
</body>
</html>
