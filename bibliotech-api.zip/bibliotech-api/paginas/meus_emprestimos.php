<?php
// meus_emprestimos.php — mostra o histórico de empréstimos da
// própria pessoa logada (pendentes, ativos, atrasados, concluídos).

session_start();
require __DIR__ . "/../config/SemCache.php";
sem_cache();
require __DIR__ . "/../config/Conexao.php";

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$idUsuario = $_SESSION["id_usuario"];
$conexao = Conexao::getConexao();
session_write_close();

$stmt = $conexao->prepare(
    "SELECT L.titulo, A.nome_autor, C.nome_cat, L.ISBN, L.editora, L.publicacao,
            E.data_emp, E.data_dev_prevista, E.data_dev,
            E.emp_ativo, E.reserva, E.multa_pendente, E.dev_pdia
     FROM emprestimo E
     INNER JOIN livros L ON L.id_livro = E.id_livro
     INNER JOIN autores A ON A.id_autor = L.id_autor
     INNER JOIN categorias C ON C.id_cat = L.id_cat
     WHERE E.id_usuario = :id
     ORDER BY E.data_emp DESC"
);
$stmt->execute([":id" => $idUsuario]);
$emprestimos = $stmt->fetchAll();

// Descobre o status de cada empréstimo, em palavras simples
function statusEmprestimo(array $item): string
{
    if ((int) $item["reserva"] === 1) {
        return "Aguardando aprovação";
    }
    if ((int) $item["emp_ativo"] === 1 && $item["data_dev"] === null) {
        return ($item["data_dev_prevista"] < date("Y-m-d")) ? "Atrasado" : "Ativo";
    }
    return "Concluído";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?= sem_cache_js() ?>
    <meta charset="UTF-8">
    <title>Meus empréstimos - Biblioteca Virtual</title>
</head>
<body>
    <h2>Meus empréstimos</h2>

    <table border="1" cellpadding="6">
        <tr>
            <th>Livro</th>
            <th>Autor</th>
            <th>Categoria</th>
            <th>ISBN</th>
            <th>Editora</th>
            <th>Ano</th>
            <th>Status</th>
            <th>Data do empréstimo</th>
            <th>Devolução prevista</th>
            <th>Devolvido em</th>
            <th>Dias de atraso</th>
            <th>Multa pendente?</th>
        </tr>
        <?php foreach ($emprestimos as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item["titulo"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["nome_autor"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["nome_cat"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["ISBN"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["editora"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars((string) $item["publicacao"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= statusEmprestimo($item) ?></td>
                <td><?= htmlspecialchars((string) $item["data_emp"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars((string) $item["data_dev_prevista"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars((string) ($item["data_dev"] ?? "—"), ENT_QUOTES, "UTF-8") ?></td>
                <td><?= (int) $item["dev_pdia"] > 0 ? $item["dev_pdia"] : "—" ?></td>
                <td><?= $item["multa_pendente"] ? "Sim" : "Não" ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($emprestimos)): ?>
            <tr><td colspan="12">Você ainda não tem nenhum empréstimo.</td></tr>
        <?php endif; ?>
    </table>

    <p><a href="principal.php">Voltar</a></p>
</body>
</html>
