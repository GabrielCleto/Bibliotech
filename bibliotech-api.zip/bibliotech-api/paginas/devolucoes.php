<?php
// devolucoes.php — bibliotecária vê os empréstimos ativos (já
// aprovados, ainda não devolvidos) e registra a devolução.

session_start();
require __DIR__ . "/../config/Conexao.php";
require __DIR__ . "/../models/Emprestimo.php";

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$tipo = $_SESSION["tipo_usuario"];
if ($tipo !== "bibliotecario" && $tipo !== "admin") {
    http_response_code(403);
    exit("Acesso restrito a bibliotecários.");
}

$conexao = Conexao::getConexao();
$logica = new Emprestimo($conexao);
$mensagem = "";

if (isset($_GET["devolver"])) {
    $resultado = $logica->registrarDevolucao((int) $_GET["devolver"]);
    $mensagem = $resultado["mensagem"];
}

$sql = "SELECT E.id_emprestimo, U.nome, L.titulo, E.data_emp, E.data_dev_prevista,
               CASE WHEN E.data_dev_prevista < CURDATE() THEN 'Sim' ELSE 'Não' END AS atrasado
        FROM emprestimo E
        INNER JOIN usuario U ON U.id_usuario = E.id_usuario
        INNER JOIN livros L ON L.id_livro = E.id_livro
        WHERE E.emp_ativo = 1 AND E.data_dev IS NULL
        ORDER BY E.data_dev_prevista";
$ativos = $conexao->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Devoluções - Biblioteca Virtual</title>
</head>
<body>
    <h2>Empréstimos ativos</h2>

    <?php if (!empty($mensagem)): ?>
        <div><?= htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8") ?></div>
    <?php endif; ?>

    <table border="1" cellpadding="6">
        <tr>
            <th>Quem pegou</th>
            <th>Livro</th>
            <th>Data do empréstimo</th>
            <th>Devolução prevista</th>
            <th>Atrasado?</th>
            <th></th>
        </tr>
        <?php foreach ($ativos as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item["nome"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["titulo"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["data_emp"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= htmlspecialchars($item["data_dev_prevista"], ENT_QUOTES, "UTF-8") ?></td>
                <td><?= $item["atrasado"] ?></td>
                <td><a href="?devolver=<?= $item["id_emprestimo"] ?>">Registrar devolução</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($ativos)): ?>
            <tr><td colspan="6">Nenhum empréstimo ativo.</td></tr>
        <?php endif; ?>
    </table>

    <p><a href="principal.php">Voltar</a></p>
</body>
</html>
