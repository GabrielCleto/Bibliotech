<?php
// solicitar_emprestimo.php — aluno/professor pede um livro
// emprestado (fica esperando aprovação da bibliotecária).

session_start();
require __DIR__ . "/../config/Conexao.php";
require __DIR__ . "/../models/Emprestimo.php";

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$tipo = $_SESSION["tipo_usuario"];
if ($tipo !== "aluno" && $tipo !== "professor") {
    http_response_code(403);
    exit("Só aluno ou professor pode solicitar empréstimo.");
}

$idLivro = (int) ($_GET["id_livro"] ?? 0);

$logica = new Emprestimo(Conexao::getConexao());
$resultado = $logica->solicitarEmprestimo($_SESSION["id_usuario"], $idLivro);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Solicitar empréstimo - Biblioteca Virtual</title>
</head>
<body>
    <h2>Solicitar empréstimo</h2>
    <p><?= htmlspecialchars($resultado["mensagem"], ENT_QUOTES, "UTF-8") ?></p>
    <p><a href="livros.php">Voltar para o acervo</a></p>
</body>
</html>
