DROP DATABASE IF EXISTS biblioteca;

CREATE DATABASE biblioteca
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

USE biblioteca;

CREATE TABLE usuario (
    id_usuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,

    tipo_usuario ENUM(
        'aluno',
        'professor',
        'bibliotecario',
        'admin'
    ) NOT NULL DEFAULT 'aluno',

    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_login DATETIME NULL,
    token_redefinicao VARCHAR(255) NULL,
    token_expiracao DATETIME NULL
);

CREATE TABLE curso (
    id_curso INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_curso VARCHAR(70) NOT NULL,
    Mtec VARCHAR(45) BINARY NOT NULL
);

CREATE TABLE turma (
    id_turma INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_curso INT NULL,
    turno VARCHAR(45) NOT NULL,
    ano_calendario INT NOT NULL,
    periodo_letivo INT NOT NULL,

    FOREIGN KEY (id_curso)
        REFERENCES curso(id_curso)
        ON UPDATE CASCADE
        ON DELETE SET NULL
);


CREATE TABLE categorias (
    id_cat INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_cat VARCHAR(30) NOT NULL UNIQUE
);


CREATE TABLE autores (
    id_autor INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_autor VARCHAR(70) NOT NULL,
    nacionalidade_autor VARCHAR(60)
);

CREATE TABLE livros (
    id_livro INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    id_autor INT NOT NULL,
    ISBN VARCHAR(17) NOT NULL UNIQUE,
    publicacao YEAR NOT NULL,
    editora VARCHAR(100) NOT NULL,
    id_cat INT NOT NULL,
    quantidade_total INT NOT NULL DEFAULT 1,
    quantidade_disponivel INT NOT NULL DEFAULT 1,

    FOREIGN KEY (id_cat)
        REFERENCES categorias(id_cat)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    FOREIGN KEY (id_autor)
        REFERENCES autores(id_autor)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE INDEX idx_livros_titulo
    ON livros(titulo);


CREATE TABLE aluno (
    RA INT NOT NULL PRIMARY KEY,

    id_usuario INT NOT NULL,
    id_turma INT NOT NULL,

    CPF_aluno VARCHAR(20) NOT NULL UNIQUE,
    dataNascimento DATE NOT NULL,
    endereco VARCHAR(200) NOT NULL,
    telefone_aluno VARCHAR(20) NOT NULL,

    situacao VARCHAR(45) NOT NULL DEFAULT 'Ativo',
    matricula BIGINT NOT NULL UNIQUE,

    FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    FOREIGN KEY (id_turma)
        REFERENCES turma(id_turma)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE TABLE professor (
    id_professor INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

    id_usuario INT NOT NULL,

    telefone_prof VARCHAR(20) NOT NULL,
    disciplina VARCHAR(50) NOT NULL,
    matricula BIGINT NOT NULL UNIQUE,

    FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);


CREATE TABLE bibliotecario (
    id_bibliotecario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

    id_usuario INT NOT NULL,

    CPF_biblio VARCHAR(20) NOT NULL UNIQUE,
    telefone_biblio VARCHAR(20) NOT NULL,

    FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE TABLE emprestimo (
    id_emprestimo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

    emp_ativo tinyint NOT NULL DEFAULT TRUE,
    reserva tinyint NOT NULL DEFAULT FALSE,
    dev_pdia INT NOT NULL DEFAULT 0,

    data_emp DATE NOT NULL,
    data_dev_prevista DATE NOT NULL,
    data_dev DATE NULL,

    multa_pendente tinyint NOT NULL DEFAULT FALSE,

    id_usuario INT NOT NULL,
    id_livro INT NOT NULL,

    FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    FOREIGN KEY (id_livro)
        REFERENCES livros(id_livro)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE INDEX idx_emprestimo_ativo
    ON emprestimo(emp_ativo);


INSERT INTO categorias (id_cat, nome_cat) VALUES
(1, 'Suspense'),
(2, 'Ficção científica'),
(3, 'Romance'),
(4, 'Fantasia'),
(5, 'Distopia'),
(6, 'Terror');


INSERT INTO autores (id_autor, nome_autor, nacionalidade_autor) VALUES
(1, 'Colleen Hoover', 'Americana'),
(2, 'Dan Brown', 'Americana'),
(3, 'Paula Hawkins', 'Britânica'),
(4, 'George Orwell', 'Britânica'),
(5, 'Frank Herbert', 'Americana'),
(6, 'Ernest Cline', 'Americana'),
(7, 'Elle Kennedy', 'Canadense'),
(8, 'Jojo Moyes', 'Britânica'),
(9, 'Jane Austen', 'Britânica'),
(10, 'C. S. Lewis', 'Britânica'),
(11, 'J. K. Rowling', 'Britânica'),
(12, 'J. R. R. Tolkien', 'Britânica'),
(13, 'Suzanne Collins', 'Americana'),
(14, 'Margaret Atwood', 'Canadense'),
(15, 'William Peter Blatty', 'Americana'),
(16, 'Stephen King', 'Americana');


INSERT INTO curso (id_curso, nome_curso, Mtec) VALUES
(1, 'Desenvolvimento de Sistemas', 'Sim'),
(2, 'Gastronomia', 'Sim'),
(3, 'Administração', 'Não'),
(4, 'Economia', 'Sim'),
(5, 'Ciências Biológicas', 'Não');


INSERT INTO turma
    (id_turma, id_curso, turno, ano_calendario, periodo_letivo)
VALUES
(1, 1, 'Manhã', 2026, 1),
(2, 1, 'Tarde', 2026, 1),
(3, 2, 'Noite', 2026, 1);


-- quantidade_disponivel ajustada: livros com empréstimo ativo (ver INSERT INTO emprestimo)
-- têm 1 cópia a menos disponível do que o total.
INSERT INTO livros
    (id_livro, titulo, id_autor, ISBN, publicacao, editora,
     id_cat, quantidade_total, quantidade_disponivel)
VALUES
(1, 'Verity', 1, '9788501117849', 2018, 'Galera Record', 1, 2, 1),
(2, 'O Código Da Vinci', 2, '8575421131', 2004, 'Sextante', 1, 2, 1),
(3, 'A Garota no Trem', 3, '9788501104656', 2015, 'Record', 1, 2, 2),
(4, '1984', 4, '9788535914849', 1949, 'Companhia das Letras', 2, 2, 1),
(5, 'Duna', 5, '9788576573135', 2017, 'Aleph', 2, 2, 2),
(6, 'Jogador Nº 1', 6, '9788580443118', 2012, 'Leya', 2, 2, 1),
(7, 'O Acordo', 7, '9788576864953', 2015, 'Paralela', 3, 2, 2),
(8, 'Como Eu Era Antes de Você', 8, '9788580573299', 2013, 'Intrínseca', 3, 2, 2),
(9, 'Orgulho e Preconceito', 9, '9788563560155', 2011, 'Penguin/Companhia das Letras', 3, 2, 2),
(10, 'As Crônicas de Nárnia', 10, '9788578270697', 1950, 'Martins Fontes', 4, 2, 2),
(11, 'Harry Potter e a Pedra Filosofal', 11, '9788532511010', 2000, 'Rocco', 4, 2, 1),
(12, 'O Senhor dos Anéis: A Sociedade do Anel', 12, '9788595084759', 2019, 'HarperCollins Brasil', 4, 2, 1),
(13, 'Jogos Vorazes', 13, '9788579800244', 2008, 'Rocco', 5, 2, 2),
(14, 'O Conto da Aia', 14, '9788532520387', 2017, 'Rocco', 5, 2, 1),
(15, 'A revolução dos bichos', 4, '9788535909555', 2007, 'Companhia das Letras', 5, 2, 2),
(16, 'O Exorcista', 15, '9788576570538', 1971, 'HarperCollins Brasil', 6, 2, 2),
(17, 'It: A Coisa', 16, '9788556510392', 2017, 'Suma', 6, 2, 2),
(18, 'O Iluminado', 16, '9788581050482', 2012, 'Suma', 6, 2, 2);


INSERT INTO usuario
    (id_usuario, nome, email, senha_hash, tipo_usuario)
VALUES
(1, 'Júlia Fonseca', 'juliazinha1134@gmail.com', 'HASH_AQUI', 'aluno'),
(2, 'Anna Beatriz Perez', 'anna.perez@hotmail.com', 'HASH_AQUI', 'aluno'),
(3, 'Maicon Araújo dos Santos', 'maicon_araujo98@outlook.com', 'HASH_AQUI', 'aluno'),
(4, 'Jussara Alves', 'jussara.alves23@gmail.com', 'HASH_AQUI', 'aluno'),
(5, 'Guilherme Cardoso', 'guicardoso@yahoo.com.br', 'HASH_AQUI', 'aluno'),
(6, 'Lucca Santiago', 'lucca.santiago07@gmail.com', 'HASH_AQUI', 'aluno'),
(7, 'Luiz Farias', 'luizfarias_@hotmail.com', 'HASH_AQUI', 'aluno'),
(8, 'Izabella Dantas', 'izadantas15@gmail.com', 'HASH_AQUI', 'aluno'),
(9, 'Nathalia Bispo', 'nathaliabispo@outlook.com', 'HASH_AQUI', 'aluno'),
(10, 'Jacqueline Pereira', 'jaque.pereira88@gmail.com', 'HASH_AQUI', 'aluno'),
(11, 'Monaly Melo', 'monalymelo21@yahoo.com.br', 'HASH_AQUI', 'aluno'),
(12, 'Junior Cardoso', 'juniorcardoso.99@gmail.com', 'HASH_AQUI', 'aluno'),
(13, 'Benedito Junior', 'benedito.jr@hotmail.com', 'HASH_AQUI', 'aluno'),
(14, 'Luiza Bittencourt', 'luizabitt@gmail.com', 'HASH_AQUI', 'aluno'),
(15, 'Santiago da Silva', 'santiago.silva77@outlook.com', 'HASH_AQUI', 'aluno'),
(16, 'Alex de Carvalho', 'alexcarvalho2024@gmail.com', 'HASH_AQUI', 'aluno'),
(17, 'Roberto Nogueira', 'roberto.nogueira@escola.edu.br', 'HASH_AQUI', 'professor'),
(18, 'Camila Ferreira Rocha', 'camila.rocha@escola.edu.br', 'HASH_AQUI', 'professor'),
(19, 'Eduardo Martins Silva', 'eduardo.silva@escola.edu.br', 'HASH_AQUI', 'professor'),
(20, 'Patrícia Souza Lima', 'patricia.lima@escola.edu.br', 'HASH_AQUI', 'bibliotecario'),
(21, 'Rafael Costa Almeida', 'rafael.almeida@escola.edu.br', 'HASH_AQUI', 'bibliotecario'),
(22, 'Vanessa Oliveira Ramos', 'vanessa.ramos@escola.edu.br', 'HASH_AQUI', 'bibliotecario'),
(23, 'Fernanda Lopes Barros', 'fernanda.barros@escola.edu.br', 'HASH_AQUI', 'professor'),
(24, 'Thiago Ribeiro Nunes', 'thiago.nunes@escola.edu.br', 'HASH_AQUI', 'professor');


INSERT INTO aluno (RA, id_usuario, id_turma, CPF_aluno,
dataNascimento, endereco, telefone_aluno, situacao, matricula)
VALUES
(1001, 1, 1,
 '123.456.789-01', '2009-03-15',
 'Rua das Flores, 100', '(11) 99999-0001',
 'Ativo', 20261001),
(1002, 2, 1,
 '123.456.789-02', '2009-07-22',
 'Rua das Palmeiras, 200', '(11) 99999-0002',
 'Ativo', 20261002),
(1003, 3, 1,
 '123.456.789-03', '2008-11-10',
 'Avenida Central, 300', '(11) 99999-0003',
 'Ativo', 20261003),
(1004, 4, 1,
 '123.456.789-04', '2009-01-28',
 'Rua das Acácias, 400', '(11) 99999-0004',
 'Ativo', 20261004),
(1005, 5, 1,
 '123.456.789-05', '2009-05-17',
 'Rua dos Ipês, 500', '(11) 99999-0005',
 'Ativo', 20261005),
(1006, 6, 1,
 '123.456.789-06', '2008-09-03',
 'Rua do Bosque, 600', '(11) 99999-0006',
 'Ativo', 20261006),
(1007, 7, 2,
 '123.456.789-07', '2009-02-14',
 'Avenida Brasil, 700', '(11) 99999-0007',
 'Ativo', 20261007),
(1008, 8, 2,
 '123.456.789-08', '2008-12-19',
 'Rua do Sol, 800', '(11) 99999-0008',
 'Ativo', 20261008),
(1009, 9, 2,
 '123.456.789-09', '2009-06-25',
 'Rua da Paz, 900', '(11) 99999-0009',
 'Ativo', 20261009),
(1010, 10, 2,
 '123.456.789-10', '2008-10-08',
 'Rua São Paulo, 1000', '(11) 99999-0010',
 'Ativo', 20261010),
(1011, 11, 2,
 '123.456.789-11', '2009-04-12',
 'Rua da Esperança, 1100', '(11) 99999-0011',
 'Ativo', 20261011),
(1012, 12, 2,
 '123.456.789-12', '2008-08-30',
 'Avenida das Nações, 1200', '(11) 99999-0012',
 'Ativo', 20261012),
(1013, 13, 2,
 '123.456.789-13', '2009-09-16',
 'Rua da Liberdade, 1300', '(11) 99999-0013',
 'Ativo', 20261013),
(1014, 14, 2,
 '123.456.789-14', '2008-07-05',
 'Rua das Palmeiras, 1400', '(11) 99999-0014',
 'Ativo', 20261014),
(1015, 15, 2,
 '123.456.789-15', '2009-11-21',
 'Rua dos Lírios, 1500', '(11) 99999-0015',
 'Ativo', 20261015),
(1016, 16, 2,
 '123.456.789-16', '2008-03-27',
 'Avenida Paulista, 1600', '(11) 99999-0016',
 'Ativo', 20261016);


INSERT INTO professor
    (id_professor, id_usuario, telefone_prof, disciplina, matricula)
VALUES
(1, 17, '92876-5745', 'Desenvolvimento de Sistemas', 30261001),
(2, 18, '93456-7812', 'Gastronomia', 30261002),
(3, 19, '94567-8923', 'Administração', 30261003),
(4, 23, '95679-1034', 'Economia', 30261004),
(5, 24, '96780-2145', 'Ciências Biológicas', 30261005);

INSERT INTO bibliotecario
    (id_bibliotecario, id_usuario, CPF_biblio, telefone_biblio)
VALUES
(1, 20, '111.222.333-44', '95678-9034'),
(2, 21, '222.333.444-55', '96789-0145'),
(3, 22, '333.444.555-66', '97890-1256');

INSERT INTO emprestimo
    (emp_ativo, reserva, dev_pdia, data_emp, data_dev_prevista,
     data_dev, multa_pendente, id_usuario, id_livro)
VALUES
(TRUE,  FALSE, 0, '2026-09-01', '2026-09-15', NULL,         FALSE, 1, 4),
(TRUE,  FALSE, 0, '2026-09-05', '2026-09-19', NULL,         FALSE, 2, 11),
(FALSE, FALSE, 0, '2026-08-10', '2026-08-24', '2026-08-22', FALSE, 3, 17),
(FALSE, FALSE, 0, '2026-08-12', '2026-08-26', '2026-08-26', FALSE, 4, 9),
(TRUE,  FALSE, 6, '2026-08-20', '2026-09-03', NULL,         TRUE,  5, 1),
(FALSE, FALSE, 0, '2026-07-15', '2026-07-29', '2026-07-28', FALSE, 6, 5),
(TRUE,  TRUE,  0, '2026-09-10', '2026-09-24', NULL,         FALSE, 7, 12),
(FALSE, FALSE, 0, '2026-08-01', '2026-08-15', '2026-08-20', FALSE, 8, 16),
(TRUE,  FALSE, 0, '2026-09-12', '2026-09-26', NULL,         FALSE, 9, 2),
(FALSE, FALSE, 0, '2026-07-01', '2026-07-15', '2026-07-14', FALSE, 10, 8),
(TRUE,  FALSE, 3, '2026-08-28', '2026-09-11', NULL,         TRUE,  11, 14),
(FALSE, FALSE, 0, '2026-06-20', '2026-07-04', '2026-07-04', FALSE, 12, 18),
(TRUE,  FALSE, 0, '2026-09-08', '2026-10-08', NULL,         FALSE, 17, 6);

SELECT
    L.id_livro,
    L.titulo,
    A.nome_autor AS autor,
    A.nacionalidade_autor AS nacionalidade,
    L.ISBN,
    L.publicacao,
    L.editora,
    C.nome_cat AS categoria,
    L.quantidade_total,
    L.quantidade_disponivel
FROM livros L
INNER JOIN categorias C
    ON L.id_cat = C.id_cat
INNER JOIN autores A
    ON L.id_autor = A.id_autor
ORDER BY L.id_livro;


SELECT
    E.id_emprestimo,
    U.nome AS pessoa,
    U.tipo_usuario,
    L.titulo AS livro,
    A.nome_autor AS autor,
    C.nome_cat AS categoria,
    E.data_emp,
    E.data_dev_prevista,
    E.data_dev,
    E.emp_ativo,
    E.multa_pendente
FROM emprestimo E
INNER JOIN usuario U
    ON E.id_usuario = U.id_usuario
INNER JOIN livros L
    ON E.id_livro = L.id_livro
INNER JOIN autores A
    ON L.id_autor = A.id_autor
INNER JOIN categorias C
    ON L.id_cat = C.id_cat
ORDER BY E.id_emprestimo;


SELECT
    A.RA,
    U.nome,
    U.email,
    A.situacao,
    T.turno,
    T.ano_calendario,
    T.periodo_letivo,
    C.nome_curso
FROM aluno A
INNER JOIN usuario U
    ON A.id_usuario = U.id_usuario
LEFT JOIN turma T
    ON A.id_turma = T.id_turma
LEFT JOIN curso C
    ON T.id_curso = C.id_curso
ORDER BY A.RA;


SELECT
    P.id_professor,
    U.nome,
    U.email,
    P.telefone_prof,
    P.disciplina
FROM professor P
LEFT JOIN usuario U
    ON P.id_usuario = U.id_usuario;


SELECT
    B.id_bibliotecario,
    U.nome,
    U.email,
    B.CPF_biblio,
    B.telefone_biblio
FROM bibliotecario B
LEFT JOIN usuario U
    ON B.id_usuario = U.id_usuario;


SELECT * FROM categorias;
SELECT * FROM autores;
SELECT * FROM usuario;
SELECT * FROM curso;
SELECT * FROM turma;
SELECT * FROM aluno;
SELECT * FROM professor;
SELECT * FROM bibliotecario;
SELECT * FROM livros;
SELECT * FROM emprestimo;

-- ============================================================
-- Tabelas novas (módulo de lista de desejos e notificações,
-- desenvolvido pelo Arthur)
-- ============================================================

CREATE TABLE lista_desejos (
    id_lista INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_livro INT NOT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_lista_usuario_livro (id_usuario, id_livro),
    CONSTRAINT fk_lista_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_lista_livro FOREIGN KEY (id_livro) REFERENCES livros(id_livro)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE notificacao (
    id_notificacao INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tipo VARCHAR(40) NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    mensagem VARCHAR(500) NOT NULL,
    lida BOOLEAN NOT NULL DEFAULT FALSE,
    criada_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lida_em DATETIME NULL,
    CONSTRAINT fk_notificacao_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE ON DELETE CASCADE,
    INDEX idx_notificacao_usuario_lida (id_usuario, lida, criada_em)
);


-- ============================================================
-- Senha de teste para todo mundo (só para ambiente de
-- desenvolvimento/testes — NUNCA usar senha igual pra todos
-- em produção de verdade). Senha: 123456
-- Equivale a rodar o definir_senhas.php depois de importar.
-- ============================================================

UPDATE usuario
SET senha_hash = '$2y$10$lLCzEzINZ.LTzxL7lQ24J.l2WbvXD.WsS5yz2vWPvxVSbN75DsS7u'
WHERE senha_hash = 'HASH_AQUI';
