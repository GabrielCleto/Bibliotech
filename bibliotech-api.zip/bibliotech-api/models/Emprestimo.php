<?php

/**
 * Classe Emprestimo
 *
 * Cuida do fluxo de empréstimo com aprovação da bibliotecária:
 * 1) solicitarEmprestimo() — aluno/professor pede o livro, que fica
 *    reservado (ninguém mais pega) esperando aprovação
 * 2) aprovarSolicitacao() — bibliotecária libera de vez, e só aí
 *    o prazo de devolução começa a contar
 * 3) recusarSolicitacao() — bibliotecária nega, a cópia volta pro
 *    estoque disponível
 * 4) registrarDevolucao() — quando o livro emprestado é devolvido
 *
 * Ela não abre conexão sozinha — recebe uma conexão PDO já pronta
 * (a mesma que a Conexao::getConexao() devolve).
 */
class Emprestimo
{
    private PDO $conexao;

    // Regras de negócio fixas do módulo
    private const LIMITE_LIVROS_SIMULTANEOS = 3;
    private const PRAZO_DIAS_ALUNO = 15;
    private const PRAZO_DIAS_PROFESSOR = 30;

    public function __construct(PDO $conexaoPdo)
    {
        $this->conexao = $conexaoPdo;
    }

    /**
     * Passo 1: aluno ou professor solicita um livro. Fica reservado
     * (emp_ativo = 0, reserva = 1) até a bibliotecária decidir.
     */
    public function solicitarEmprestimo(int $idUsuario, int $idLivro): array
    {
        try {
            $this->conexao->beginTransaction();

            // 1) O usuário existe e está ativo?
            $stmt = $this->conexao->prepare(
                "SELECT id_usuario, tipo_usuario, ativo FROM usuario WHERE id_usuario = :id"
            );
            $stmt->execute([':id' => $idUsuario]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$usuario) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Usuário não encontrado.');
            }

            if ((int) $usuario['ativo'] === 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Conta desativada. Não é possível solicitar empréstimos.');
            }

            // 2) Só aluno e professor podem solicitar
            $tipo = $usuario['tipo_usuario'];
            if ($tipo !== 'aluno' && $tipo !== 'professor') {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Apenas alunos e professores podem solicitar empréstimos.');
            }

            // 3) Limite de livros (conta os já emprestados MAIS os
            // que já estão esperando aprovação, pra não deixar
            // acumular pedido demais)
            $stmt = $this->conexao->prepare(
                "SELECT COUNT(*) AS total FROM emprestimo
                 WHERE id_usuario = :id AND (emp_ativo = 1 OR reserva = 1)"
            );
            $stmt->execute([':id' => $idUsuario]);
            $totalAtivos = (int) $stmt->fetch(PDO::FETCH_ASSOC)['total'];

            if ($totalAtivos >= self::LIMITE_LIVROS_SIMULTANEOS) {
                $this->conexao->rollBack();
                return $this->resposta(
                    false,
                    'Limite de ' . self::LIMITE_LIVROS_SIMULTANEOS . ' livros (emprestados ou pendentes) atingido.'
                );
            }

            // 4) O livro existe e tem cópia disponível?
            $stmt = $this->conexao->prepare(
                "SELECT id_livro, titulo, quantidade_disponivel FROM livros WHERE id_livro = :id"
            );
            $stmt->execute([':id' => $idLivro]);
            $livro = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$livro) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Livro não encontrado.');
            }

            if ((int) $livro['quantidade_disponivel'] <= 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Livro indisponível no momento.');
            }

            // 4.5) A pessoa já tem esse MESMO livro emprestado ou
            // pendente? Não pode duplicar o mesmo título (mas pode
            // ter outros livros diferentes, até o limite de 3)
            $stmt = $this->conexao->prepare(
                "SELECT COUNT(*) AS total FROM emprestimo
                 WHERE id_usuario = :usuario AND id_livro = :livro AND (emp_ativo = 1 OR reserva = 1)"
            );
            $stmt->execute([':usuario' => $idUsuario, ':livro' => $idLivro]);
            if ((int) $stmt->fetch(PDO::FETCH_ASSOC)['total'] > 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Você já tem esse livro emprestado ou pendente de aprovação.');
            }

            // 5) Cria a solicitação. As datas ainda não valem nada de
            // verdade (a coluna é obrigatória no banco) — só quando
            // a bibliotecária aprovar é que elas ficam certas.
            $hoje = (new DateTime())->format('Y-m-d');
            $stmt = $this->conexao->prepare(
                "INSERT INTO emprestimo
                    (emp_ativo, reserva, dev_pdia, multa_pendente, data_emp, data_dev_prevista, data_dev, id_livro, id_usuario)
                 VALUES
                    (0, 1, 0, 0, :data, :data, NULL, :id_livro, :id_usuario)"
            );
            $stmt->execute([
                ':data'       => $hoje,
                ':id_livro'   => $idLivro,
                ':id_usuario' => $idUsuario,
            ]);
            $idEmprestimo = (int) $this->conexao->lastInsertId();

            // 6) Reserva a cópia (some do estoque disponível, mesmo
            // sem estar emprestada de verdade ainda)
            $stmt = $this->conexao->prepare(
                "UPDATE livros SET quantidade_disponivel = quantidade_disponivel - 1 WHERE id_livro = :id"
            );
            $stmt->execute([':id' => $idLivro]);

            // 7) Avisa toda bibliotecária ativa, na hora
            $stmt = $this->conexao->prepare(
                "SELECT id_usuario FROM usuario WHERE tipo_usuario = 'bibliotecario' AND ativo = 1"
            );
            $stmt->execute();
            $bibliotecarios = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $mensagemAviso = "{$usuario['tipo_usuario']} solicitou o livro \"{$livro['titulo']}\". Aguardando aprovação.";
            $inserirNotificacao = $this->conexao->prepare(
                "INSERT INTO notificacao (id_usuario, tipo, titulo, mensagem)
                 VALUES (:id_usuario, 'solicitacao_emprestimo', 'Nova solicitação de empréstimo', :mensagem)"
            );
            foreach ($bibliotecarios as $idBibliotecario) {
                $inserirNotificacao->execute([
                    ':id_usuario' => $idBibliotecario,
                    ':mensagem'   => $mensagemAviso,
                ]);
            }

            // 8) Avisa quem solicitou, confirmando que o pedido foi
            // enviado (ainda esperando decisão da bibliotecária)
            $stmt = $this->conexao->prepare(
                "INSERT INTO notificacao (id_usuario, tipo, titulo, mensagem)
                 VALUES (:id_usuario, 'solicitacao_enviada', 'Solicitação enviada',
                         :mensagem)"
            );
            $stmt->execute([
                ':id_usuario' => $idUsuario,
                ':mensagem' => "Sua solicitação do livro \"{$livro['titulo']}\" foi enviada e está aguardando aprovação da bibliotecária.",
            ]);

            $this->conexao->commit();

            return $this->resposta(true, 'Solicitação enviada. Aguardando aprovação da bibliotecária.', $idEmprestimo);
        } catch (Exception $e) {
            $this->conexao->rollBack();
            return $this->resposta(false, 'Erro ao solicitar empréstimo: ' . $e->getMessage());
        }
    }

    /**
     * Passo 2 (caminho "sim"): bibliotecária aprova a solicitação.
     * Só agora o prazo de devolução é calculado de verdade.
     */
    public function aprovarSolicitacao(int $idEmprestimo): array
    {
        try {
            $this->conexao->beginTransaction();

            $stmt = $this->conexao->prepare(
                "SELECT E.id_emprestimo, E.reserva, E.emp_ativo, E.id_usuario, U.tipo_usuario, L.titulo
                 FROM emprestimo E
                 INNER JOIN usuario U ON U.id_usuario = E.id_usuario
                 INNER JOIN livros L ON L.id_livro = E.id_livro
                 WHERE E.id_emprestimo = :id"
            );
            $stmt->execute([':id' => $idEmprestimo]);
            $solicitacao = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$solicitacao || (int) $solicitacao['reserva'] !== 1 || (int) $solicitacao['emp_ativo'] !== 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Solicitação não encontrada ou já foi decidida antes.');
            }

            $prazoDias = ($solicitacao['tipo_usuario'] === 'professor')
                ? self::PRAZO_DIAS_PROFESSOR
                : self::PRAZO_DIAS_ALUNO;

            $dataEmprestimo = new DateTime();
            $dataPrevista = (clone $dataEmprestimo)->modify('+' . $prazoDias . ' days');

            $stmt = $this->conexao->prepare(
                "UPDATE emprestimo
                 SET reserva = 0, emp_ativo = 1, data_emp = :data_emp, data_dev_prevista = :data_dev_prevista
                 WHERE id_emprestimo = :id"
            );
            $stmt->execute([
                ':data_emp'          => $dataEmprestimo->format('Y-m-d'),
                ':data_dev_prevista' => $dataPrevista->format('Y-m-d'),
                ':id'                => $idEmprestimo,
            ]);

            // Avisa quem pediu que foi aprovado
            $mensagem = "Seu pedido do livro \"{$solicitacao['titulo']}\" foi aprovado. "
                . "Devolução prevista para " . $dataPrevista->format('d/m/Y') . ".";
            $stmt = $this->conexao->prepare(
                "INSERT INTO notificacao (id_usuario, tipo, titulo, mensagem)
                 VALUES (:id_usuario, 'emprestimo_aprovado', 'Empréstimo aprovado', :mensagem)"
            );
            $stmt->execute([':id_usuario' => $solicitacao['id_usuario'], ':mensagem' => $mensagem]);

            $this->conexao->commit();

            return $this->resposta(true, 'Solicitação aprovada. Empréstimo liberado.', $idEmprestimo);
        } catch (Exception $e) {
            $this->conexao->rollBack();
            return $this->resposta(false, 'Erro ao aprovar solicitação: ' . $e->getMessage());
        }
    }

    /**
     * Passo 2 (caminho "não"): bibliotecária recusa a solicitação.
     * A cópia volta pro estoque disponível, e o pedido é removido
     * (nunca chegou a virar empréstimo de verdade).
     */
    public function recusarSolicitacao(int $idEmprestimo): array
    {
        try {
            $this->conexao->beginTransaction();

            $stmt = $this->conexao->prepare(
                "SELECT E.id_emprestimo, E.reserva, E.emp_ativo, E.id_usuario, E.id_livro, L.titulo
                 FROM emprestimo E
                 INNER JOIN livros L ON L.id_livro = E.id_livro
                 WHERE E.id_emprestimo = :id"
            );
            $stmt->execute([':id' => $idEmprestimo]);
            $solicitacao = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$solicitacao || (int) $solicitacao['reserva'] !== 1 || (int) $solicitacao['emp_ativo'] !== 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Solicitação não encontrada ou já foi decidida antes.');
            }

            $stmt = $this->conexao->prepare("DELETE FROM emprestimo WHERE id_emprestimo = :id");
            $stmt->execute([':id' => $idEmprestimo]);

            $stmt = $this->conexao->prepare(
                "UPDATE livros SET quantidade_disponivel = quantidade_disponivel + 1 WHERE id_livro = :id"
            );
            $stmt->execute([':id' => $solicitacao['id_livro']]);

            // Avisa quem pediu que foi recusado
            $mensagem = "Seu pedido do livro \"{$solicitacao['titulo']}\" foi recusado pela bibliotecária.";
            $stmt = $this->conexao->prepare(
                "INSERT INTO notificacao (id_usuario, tipo, titulo, mensagem)
                 VALUES (:id_usuario, 'emprestimo_recusado', 'Empréstimo recusado', :mensagem)"
            );
            $stmt->execute([':id_usuario' => $solicitacao['id_usuario'], ':mensagem' => $mensagem]);

            $this->conexao->commit();

            return $this->resposta(true, 'Solicitação recusada.');
        } catch (Exception $e) {
            $this->conexao->rollBack();
            return $this->resposta(false, 'Erro ao recusar solicitação: ' . $e->getMessage());
        }
    }

    /**
     * Registra a devolução de um livro já emprestado (aprovado).
     */
    public function registrarDevolucao(int $idEmprestimo): array
    {
        try {
            $this->conexao->beginTransaction();

            $stmt = $this->conexao->prepare(
                "SELECT id_emprestimo, emp_ativo, id_livro FROM emprestimo WHERE id_emprestimo = :id"
            );
            $stmt->execute([':id' => $idEmprestimo]);
            $emprestimo = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$emprestimo) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Empréstimo não encontrado.');
            }

            if ((int) $emprestimo['emp_ativo'] === 0) {
                $this->conexao->rollBack();
                return $this->resposta(false, 'Este empréstimo já foi devolvido anteriormente.');
            }

            $dataDevolucao = new DateTime();
            $stmt = $this->conexao->prepare(
                "UPDATE emprestimo SET emp_ativo = 0, data_dev = :data_dev WHERE id_emprestimo = :id"
            );
            $stmt->execute([
                ':data_dev' => $dataDevolucao->format('Y-m-d'),
                ':id'       => $idEmprestimo,
            ]);

            $stmt = $this->conexao->prepare(
                "UPDATE livros SET quantidade_disponivel = quantidade_disponivel + 1 WHERE id_livro = :id"
            );
            $stmt->execute([':id' => $emprestimo['id_livro']]);

            $this->conexao->commit();

            return $this->resposta(true, 'Devolução registrada com sucesso.');
        } catch (Exception $e) {
            $this->conexao->rollBack();
            return $this->resposta(false, 'Erro ao processar devolução: ' . $e->getMessage());
        }
    }

    private function resposta(bool $sucesso, string $mensagem, ?int $idEmprestimo = null): array
    {
        return [
            'sucesso'       => $sucesso,
            'mensagem'      => $mensagem,
            'id_emprestimo' => $idEmprestimo,
        ];
    }
}
