<?php

// Esse arquivo é só pra gente testar a API do Arthur, já que o
// login de verdade (do Vinícius) ainda não existe. Ele faz login
// com um usuário de teste e já deixa a sessão criada.
//
// Depois que o Vinícius mandar a página de login de verdade, esse
// arquivo pode ser apagado.

require_once "config/Conexao.php";
require_once "models/Usuario.php";

session_start();

// Muda aqui pra testar com outro tipo de usuário
$email_digitado = "juliazinha1134@gmail.com";
$senha_digitada = "123456";

$resultado = Usuario::autenticar($email_digitado, $senha_digitada);

if ($resultado["sucesso"] === false) {
    echo $resultado["mensagem"];
} else {
    $_SESSION["id_usuario"] = $resultado["usuario"]->pegarId();
    $_SESSION["tipo_usuario"] = $resultado["usuario"]->pegarTipoUsuario();

    echo "Sessão criada para " . $resultado["usuario"]->pegarNome();
    echo " (id_usuario: " . $_SESSION["id_usuario"] . ", tipo: " . $_SESSION["tipo_usuario"] . ")";
    echo "<br>Agora abra, na MESMA aba do navegador, por exemplo:";
    echo "<br><a href='api/wishlist'>bibliotech-api/api/wishlist</a>";
}
