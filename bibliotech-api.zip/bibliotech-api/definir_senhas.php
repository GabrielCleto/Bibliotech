<?php
// definir_senhas.php — USO ÚNICO, só para testes.
// Troca o 'HASH_AQUI' do script SQL por um hash real de uma senha de teste.
// APAGUE ESTE ARQUIVO depois de rodar.

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Acesso negado.');
}

require __DIR__ . '/config/Conexao.php';

$pdo = Conexao::getConexao();
$senhaTeste = 'Teste@123'; // troque se quiser

$stmt = $pdo->prepare("UPDATE usuario SET senha_hash = :hash WHERE senha_hash = 'HASH_AQUI'");
$stmt->execute([':hash' => password_hash($senhaTeste, PASSWORD_DEFAULT)]);

echo $stmt->rowCount() . ' usuário(s) atualizado(s). Senha de teste: ' . htmlspecialchars($senhaTeste)
   . '. Agora apague este arquivo.';
