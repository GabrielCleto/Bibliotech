<?php

// Esse arquivo é só pra gente testar se o login está funcionando.
// Ele não é a versão final, é tipo um "rascunho de teste".

// Primeiro, precisamos trazer o código das classes que criamos
require_once "config/Conexao.php";
require_once "models/Usuario.php";

// Aqui a gente simula alguém digitando o e-mail e a senha
$email_digitado = "juliazinha1134@gmail.com";
$senha_digitada = "123456";

// Chama a função de login que fizemos na classe Usuario
// Agora ela devolve um array, não mais um usuário direto
$resultado = Usuario::autenticar($email_digitado, $senha_digitada);

// Mostra a mensagem que veio no array
if ($resultado["sucesso"] === false) {
    echo $resultado["mensagem"];
} else {
    echo $resultado["mensagem"] . " Bem-vindo(a), " . $resultado["usuario"]->pegarNome();
    echo " (tipo: " . $resultado["usuario"]->pegarTipoUsuario() . ")";
}
