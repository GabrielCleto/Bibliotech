<?php

// Esse arquivo é só pra testar o que acontece quando ninguém
// está logado. Ele apaga a sessão atual (é tipo um "logout").

session_start();
session_destroy();

echo "Sessão encerrada. Agora tente acessar alguma rota da API,";
echo " tipo <a href='api/wishlist'>bibliotech-api/api/wishlist</a>,";
echo " sem ter feito login de novo.";
